import 'package:flutter/material.dart';

void main() {
  runApp(const CalculatorApp());
}

class CalculatorApp extends StatelessWidget {
  const CalculatorApp({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      home: Center(
        child: SizedBox(
          width: 300, // 계산기 전체 너비
          height: 500, // 계산기 전체 높이
          child: CalculatorScreen(),
        ),
      ),
    );
  }
}

class CalculatorScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      appBar: AppBar(
        title: const Text(
          '계산기',
          style: TextStyle(color: Colors.white),
        ),
        backgroundColor: Colors.black,
        elevation: 0,
      ),
      body: Column(
        children: [
          // 상단 출력 영역
          Container(
            height: 80, // 출력 영역 높이 축소
            alignment: Alignment.bottomRight,
            padding: const EdgeInsets.all(10),
            child: const Text(
              '0',
              style: TextStyle(color: Colors.white, fontSize: 36),
            ),
          ),
          // 첫 번째 줄 (작은 버튼 6개)
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceEvenly,
            children: smallButtonLabels.map((label) {
              return SizedBox(
                width: 45, // 작은 버튼 너비
                height: 40, // 작은 버튼 세로 폭 좁힘
                child: ElevatedButton(
                  onPressed: () {}, // 기능 없음
                  style: ElevatedButton.styleFrom(
                    backgroundColor: Colors.grey[800],
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(4),
                    ),
                  ),
                  child: Center(
                    child: Text(
                      label,
                      textAlign: TextAlign.center, // 텍스트를 가로 정렬
                      style:
                      const TextStyle(color: Colors.white, fontSize: 12),
                    ),
                  ),
                ),
              );
            }).toList(),
          ),
          const SizedBox(height: 10), // 작은 버튼 아래 여백 추가
          // 나머지 버튼 (4개씩 배치)
          Expanded(
            child: GridView.builder(
              padding: const EdgeInsets.all(5),
              gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                crossAxisCount: 4, // 한 줄에 버튼 4개
                crossAxisSpacing: 6, // 버튼 간 가로 간격
                mainAxisSpacing: 6, // 버튼 간 세로 간격 축소
                childAspectRatio:
                1.5, // 버튼의 가로 대비 세로 비율을 조정하여 세로 폭을 좁힘
              ),
              itemCount: buttonLabels.length,
              itemBuilder: (context, index) {
                return ElevatedButton(
                  onPressed: () {}, // 기능 없음
                  style: ElevatedButton.styleFrom(
                    backgroundColor:
                    index == buttonLabels.length - 1 ? Colors.blue : Colors.grey[800],
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(4),
                    ),
                  ),
                  child: Text(
                    buttonLabels[index],
                    style:
                    const TextStyle(color: Colors.white, fontSize: 12),
                  ),
                );
              },
            ),
          ),
        ],
      ),
    );
  }
}

// 첫 번째 줄 작은 버튼 텍스트 리스트
const List<String> smallButtonLabels = ['MC', 'MR', 'M+', 'M-', 'MS', 'M'];

// 나머지 버튼 텍스트 리스트
const List<String> buttonLabels = [
  '%', 'CE', 'C', '⌫',
  '1/x', 'x²', '²√x', '/',
  '7', '8', '9', '*',
  '4', '5', '6', '-',
  '1', '2', '3', '+',
  '+/-', '0', '.', '='
];
