package com.example.w5_hw2

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
